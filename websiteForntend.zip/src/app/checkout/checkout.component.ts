import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from '../auth.service';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {

  states = ["Select..","Andhpradesh","Bihar","Hyderabad","Karnatak","Kerla","Madhya Pradesh","Maharastra","Noida","Tamilanadu","UttarPradesh",""];
 
  country = ["Select..","India","America","California","China","England","Koria","Rasia","Viatnaam"];

  public cartItemList :any = [];
  public total :number = 0;
  public adrs : string = "";


  constructor(private cart : CartService, private auth: AuthService) { }

  ngOnInit(): void {
    this.cart.getProducts().subscribe(res => {
      this.cartItemList = res;
    
      this.total = this.cart.getTotalPrice();
    })


   
    }
  


  onSave(detail : NgForm){
    if(detail.invalid){
      return;
    }
    this.adrs = detail.value.address;
    this.auth.saveOrderDetails(detail.value.fname,detail.value.lname,detail.value.mno,detail.value.email,detail.value.address)
    alert("your response has been submited successfully")
  }

  // check(){
  //   if(this.adrs == ""){
  //     alert("Add your address");
  //     return;
  //   }
  
//} 
 

}
