import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { CartComponent } from './cart/cart.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { CustomizedcakeComponent } from './customizedcake/customizedcake.component';
import { EggcakeComponent } from './eggcake/eggcake.component';
import { EglessComponent } from './egless/egless.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ProductComponent } from './product/product.component';
import { RegisterComponent } from './register/register.component';
import { FooterComponent } from './footer/footer.component';
import { CheckoutComponent } from './checkout/checkout.component';

const routes: Routes = [
  {path:"",pathMatch:"full",redirectTo:"/login"},
 
  {path:'home',component:HomeComponent},
  {path:'product',component:ProductComponent},
  {path:'about',component:AboutComponent},
  {path:'contact-us',component:ContactUsComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'cart',component:CartComponent},
  {path:'eggcake',component:EggcakeComponent},
  {path: 'egless',component:EglessComponent},
  {path: 'customizedcake',component:CustomizedcakeComponent},
  {path:'footer',component:FooterComponent},
  {path:'checkout',component:CheckoutComponent}
  
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
