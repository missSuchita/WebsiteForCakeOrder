import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EggcakeComponent } from './eggcake.component';

describe('EggcakeComponent', () => {
  let component: EggcakeComponent;
  let fixture: ComponentFixture<EggcakeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EggcakeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EggcakeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
