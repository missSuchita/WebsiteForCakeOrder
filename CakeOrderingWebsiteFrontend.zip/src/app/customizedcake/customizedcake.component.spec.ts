import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomizedcakeComponent } from './customizedcake.component';

describe('CustomizedcakeComponent', () => {
  let component: CustomizedcakeComponent;
  let fixture: ComponentFixture<CustomizedcakeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomizedcakeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomizedcakeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
