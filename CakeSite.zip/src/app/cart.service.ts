import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  public cartItemList : any = [];
  public productList = new BehaviorSubject<any>([]);  //// initialize it with empty []array // behaviorSubject is act as both emit and subscriber (as observable)

  constructor() { }
 
  //Geeter method
  getProducts(){
      // return this.cartItemList;
    return this.productList.asObservable();
  }

  //Setter method
  setProduct(product : any){
    this.cartItemList.push(...product);  //push item in productlist
    this.productList.next(product);   // emit product next means it will pass the data where it will subscribe(call)
  }

  addtoCart(product : any){
    this.cartItemList.push(product);
    this.productList.next(this.cartItemList);
    this.getTotalPrice();
    console.log(this.cartItemList);
  }

  getTotalPrice() : number{
    let Total = 0;
    this.cartItemList.map((a : any)=>{ 
      console.log(a.price)      //map is a method of array
      Total += a.price;
    })
    console.log(Total);
    return Total;
  }

  removeCartItem(product : any){
    this.cartItemList.map((a : any,index:any) => {
      if(product.id === a.id){
        this.cartItemList.splice(index,1);   //splice...
      }
    })
    this.productList.next(this.cartItemList); 
  }

  removeAllCartItem(){
    this.cartItemList = []
    this.productList.next(this.cartItemList);  //pass this cart item to my product item
  }
}
