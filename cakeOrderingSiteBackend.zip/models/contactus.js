const mongoose = require('mongoose')

const contactSchema = new mongoose.Schema({
    name : {type: String},
    mobileNo : {type : Number},
    email : {type : String},
    msg : {type:String}
})

module.exports = mongoose.model('Contact',contactSchema);