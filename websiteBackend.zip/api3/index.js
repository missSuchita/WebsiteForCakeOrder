const express = require('express');
const router = express.Router();

require('./routes/custmcake')(router);

module.exports = router;