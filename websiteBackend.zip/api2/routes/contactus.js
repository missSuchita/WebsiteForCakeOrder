const express = require('express')
const contact = require('../../models/contactus')


module.exports = function(router){

    router.post('/data',(req,res)=>{
        let values = new contact(req.body)
        values.save(function(err,values){
            if(err){
               return res.status(400).json(err)
            }
           res.status(200).json(values);
        })
    })


    router.get('/getdata',(req,res)=>{
        contact.find({},(err,data)=>{
            if(err){
                res.json({success: false,message:err})
            }
            else{
                if(!contact){
                    res.json({success:false,message:'no contact found'})
                }
                else{
                    res.json({succes:true,data : data})
                }
            }
        })
    })
}