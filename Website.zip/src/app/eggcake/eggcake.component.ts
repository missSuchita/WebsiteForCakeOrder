import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-eggcake',
  templateUrl: './eggcake.component.html',
  styleUrls: ['./eggcake.component.css']
})
export class EggcakeComponent implements OnInit {

  imageSrc = [{image:"https://www.labonelfinebaking.shop/wp-content/uploads/2021/02/CLASSIC-CHOCOLATE-CAKE.jpg",name:"Chocolate Flavour",price:600},
{image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSkOEgb1YajViapzox0yxwTbGGhkzhTDmJOlltBBlwWDo3DtYO_cGb-8aKXLXPNZMCBo6A&usqp=CAU",name:"Vanila Flaour",price:650},
{image:"https://www.myflowergift.com/media/catalog/product/cache/15050e624a3f08e38dd3bdad5c791865/1/_/1_kg_pineapple_cool_cake_1600.jpg",name:"PineApple Flavour",price:750},
{image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSwinv-4XUNdC9AL3H3DWRYae1cor-taw3swQ&usqp=CAU",name:"Blue Berry Flavour",price:550},
{image:"https://www.flowersnemotions.com/image/cache/catalog/1%20product/30862_butter-scotch-cake-1000x1000.jpeg",name:"Butter Scotch",price:450},
{image:"https://thenaturalbakery.ie/wp-content/uploads/2022/01/IMG_0215-300x300.jpg",name:"Chocolate Flavour",price:599},
{image:"https://sugarandsparrow.s3.us-west-2.amazonaws.com/flour/wp-content/uploads/2021/01/31211755/Raspberry-Chocolate-Cake-Header.jpg",name:"Ruspberry",price:699},
{image:"https://i1.fnp.com/images/pr/l/v20220202161513/valentine-s-heart-red-velvet-cake-1-kg_1.jpg",name:"Red Velvet",price:499},
{image:"https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fimg1.cookinglight.timeinc.net%2Fsites%2Fdefault%2Ffiles%2Fstyles%2Fmedium_2x%2Fpublic%2F1542062283%2Fchocolate-and-cream-layer-cake-1812-cover.jpg%3Fitok%3DrEWL7AIN",name:"Strawberry Flavour",price:699}]
 
public number = [2,5,6,78,9];

public totalItem : number = 0
constructor(private cart : CartService) { }

  ngOnInit(): void {
    this.cart.getProducts().subscribe(res =>{
      this.totalItem = res.length;  //length the property which we get on response
    })
  }

  addtoCart(item : any){     //// item which is coming from .html file it consist of product item 
    this.cart.addtoCart(item);
  }

  removeItem(){
    this.cart.removeAllCartItem();
  }

  hello(i:any){
    console.log(i);
  }
}
